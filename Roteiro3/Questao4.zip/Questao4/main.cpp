#include "SistemaGerenciaFolha.h"
#include <string>
#include <iostream>

int main (void){
    SistemaGerenciaFolha sistema;
    sistema.setFuncionarios();
    //sistema.setFuncionarios();
    //sistema.setFuncionarios();
    std::string nome;
    std::cout<<"Digite o nome que voce deseja buscar: \n";
    std::cin>>nome;
    sistema.consultaSalarioFuncionario(nome);
    sistema.calculaValorTotalFolha();
    return 0;
}