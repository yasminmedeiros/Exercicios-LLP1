#include "Assalariado.h"
Assalariado::Assalariado(){}
    
double Assalariado::calcularSalario (){}
double Assalariado::getsalario(){return this->salario;}
void Assalariado::setsalario(double salario){ this->salario=salario;}