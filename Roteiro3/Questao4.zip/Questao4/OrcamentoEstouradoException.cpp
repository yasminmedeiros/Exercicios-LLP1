#include "OrcamentoEstouradoException.h"

OrcamentoEstouradoException::OrcamentoEstouradoException (){
}
std::string OrcamentoEstouradoException::getMensagem(){return this->mensagem;}